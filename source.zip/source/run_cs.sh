#!/bin/bash
if test $DYLD_FALLBACK_LIBRARY_PATH
then
export DYLD_FALLBACK_LIBRARY_PATH=${DYLD_FALLBACK_LIBRARY_PATH}:$(dirname $0)/lib
else
export DYLD_FALLBACK_LIBRARY_PATH=${HOME}/lib:/usr/local/lib:/usr/lib:/opt/local/lib:$(dirname $0)/lib
fi
$(dirname $0)/chartsweeper-0.1 $@
