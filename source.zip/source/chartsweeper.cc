#include "sox.h"
#include <stdexcept>
#include <fstream>
#include <sstream>
#include <iostream>
#include <vector>
#include <functional>
#include <numeric>
#include <cstring>

namespace {
struct file_handle {
  sox_format_t* h_;

  file_handle(sox_format_t* h) : h_(h) {}
  ~file_handle() {
    if (h_)
      sox_close(h_);
  }
};

struct effect_handle {
  sox_effect_t* h_;

  effect_handle(sox_effect_t* h) : h_(h) {}
  ~effect_handle() {
    if (h_)
      sox_delete_effect(h_);
  }
};

struct chain_handle {
  sox_effects_chain_t* h_;
  sox_signalinfo_t sig_in_; // will be modified by add_effect
  sox_signalinfo_t* sig_out_;
  bool empty_;

  chain_handle(sox_encodinginfo_t* in, sox_encodinginfo_t* out,
               sox_signalinfo_t* sig_in, sox_signalinfo_t* sig_out)
    : h_(sox_create_effects_chain(in, out)), sig_in_(*sig_in),
      sig_out_(sig_out), empty_(true) {
    if (!h_)
      throw std::runtime_error("Error creating chain");
  }

  ~chain_handle() {
    if (h_)
      sox_delete_effects_chain(h_);
  }

  void add_effect(const sox_effect_handler_t& eh, int argc, char* const argv[]);

  void add_effect(const char* name, int argc, char* const argv[]) {
    const sox_effect_handler_t* eh = sox_find_effect(name);
    if (!eh) {
      std::ostringstream os;
      os << "Could not find effect " << name;
      throw std::runtime_error(os.str());
    }
    add_effect(*eh, argc, argv);
  }
};

void chain_handle::add_effect(const sox_effect_handler_t& eh, int argc,
                              char* const argv[]) {
  effect_handle e(sox_create_effect(&eh));
  if (!e.h_) {
    std::ostringstream os;
    os << "Error creating effect " << eh.name;
    throw std::runtime_error(os.str());
  }
  if (argc && sox_effect_options(e.h_, argc, argv) != SOX_SUCCESS) {
    std::ostringstream os;
    os << "Error setting options for effect " << eh.name;
    throw std::runtime_error(os.str());
  }
  if (sox_add_effect(h_, e.h_, &sig_in_, empty_ ? &sig_in_ : sig_out_)
      != SOX_SUCCESS) {
    std::ostringstream os;
    os << "Error adding effect " << eh.name;
    throw std::runtime_error(os.str());
  }
  empty_ = false;
  e.h_ = 0;
}

class chartsweep {
public:
  static const size_t ext_rate_ = 44100;
  static const size_t ext_channels_ = 2;

private:
  const double search_start_;
  const double search_stop_;
  const double chunk_dur_;
  const size_t chunk_num_;
  const double peak_offset_;
  const double ext_dur_;
  const double fade_dur_;
  const double peak_pos_;
  const size_t ext_len_;
  const size_t fade_len_;

  std::vector<sox_sample_t> chunk_;
  double * const chunk_energy_;

  sox_sample_t * const extract_;
  sox_sample_t * const fade_buf_;
  sox_sample_t *prev_fade_;
  sox_sample_t *next_fade_;
  size_t store_pos_;
  size_t store_end_;
  size_t fade_pos_;

  // sox effect handlers
  static int options(sox_effect_t* effp, int argc, char* argv[]);
  static int start(sox_effect_t* effp);
  static int flow(sox_effect_t* effp, const sox_sample_t* ibuf, sox_sample_t*,
                  size_t* isamp, size_t* osamp);
  static sox_effect_handler_t effect_handler;

  bool read_chunk(sox_format_t* in);
  double get_energy(sox_format_t* in);
  double find_peak(const char* filename);
  void append_extract(const char* filename, double peak_time,
                      sox_format_t* out);

public:
  chartsweep(double search_start, double search_stop, double chunk_dur,
             size_t chunk_num, double ext_dur, double fade_dur,
             double peak_pos);

  ~chartsweep();

  void process_file(const char* filename, sox_format_t* out) {
    append_extract(filename, find_peak(filename), out);
  }

  void fade_out_last(sox_format_t* out);
};

chartsweep::chartsweep(double search_start, double search_stop,
                       double chunk_dur, size_t chunk_num, double ext_dur,
                       double fade_dur, double peak_pos)
  : search_start_(search_start), search_stop_(search_stop),
    chunk_dur_(chunk_dur), chunk_num_(chunk_num), ext_dur_(ext_dur),
    fade_dur_(fade_dur), peak_pos_(peak_pos * ext_dur_),
    ext_len_(static_cast<size_t>(ext_dur_ * ext_rate_) * ext_channels_),
    fade_len_(static_cast<size_t>(fade_dur_ * ext_rate_) * ext_channels_),
    peak_offset_((chunk_dur_ * chunk_num_) * 0.5),
    chunk_energy_(new double[chunk_num_]), extract_(new sox_sample_t[ext_len_]),
    fade_buf_(fade_len_ ? new sox_sample_t[fade_len_ * 2] : 0), prev_fade_(0),
    next_fade_(fade_len_ ? fade_buf_ + fade_len_ : 0) {
}

chartsweep::~chartsweep() {
  delete [] fade_buf_;
  delete [] extract_;
  delete [] chunk_energy_;
}

int chartsweep::options(sox_effect_t* effp, int argc, char* argv[]) {
  if (argc != 2 || !argv[1])
    return SOX_EINVAL;
  *reinterpret_cast<chartsweep**>(effp->priv)
    = reinterpret_cast<chartsweep*>(argv[1]);
  return SOX_SUCCESS;
}

int chartsweep::start(sox_effect_t* effp) {
  chartsweep& c = **reinterpret_cast<chartsweep**>(effp->priv);
  c.store_pos_ = 0;
  c.store_end_ = c.ext_len_;

  // read fewer samples from the first file to preserve overall length
  if (!c.prev_fade_ && c.fade_len_)
    c.store_end_ -= c.fade_len_;
  c.fade_pos_ = 0;
  return SOX_SUCCESS;
}

int chartsweep::flow(sox_effect_t* effp, const sox_sample_t* ibuf,
                     sox_sample_t*, size_t* isamp, size_t* osamp) {
  chartsweep& c = **reinterpret_cast<chartsweep**>(effp->priv);
  *osamp = 0;
  size_t to_store, to_fade;
  if (c.store_pos_ < c.store_end_) {
    size_t end_pos = c.store_pos_ + *isamp;
    if (end_pos <= c.store_end_) {
      to_store = *isamp;
      to_fade = 0;
    }
    else {
      to_store = c.store_end_ - c.store_pos_;
      to_fade = *isamp - to_store;
    }
    std::memcpy(c.extract_ + c.store_pos_, ibuf, to_store * sizeof(sox_sample_t));
    c.store_pos_ += to_store;
  }
  else if (c.fade_pos_ == c.fade_len_) {
    *isamp = 0;
    return SOX_EOF;
  }
  else {
    to_store = 0;
    to_fade = *isamp;
  }
  size_t end_pos = c.fade_pos_ + to_fade;
  if (end_pos > c.fade_len_) {
    end_pos = c.fade_len_;
    to_fade = end_pos - c.fade_pos_;
  }
  if (to_fade) {
    std::memcpy(c.next_fade_ + c.fade_pos_, ibuf + to_store,
                to_fade * sizeof(sox_sample_t));
    c.fade_pos_ = end_pos;
  }
  *isamp = to_store + to_fade;
  return SOX_SUCCESS;
}

sox_effect_handler_t chartsweep::effect_handler = {
  "chartsweep", NULL, SOX_EFF_MCHAN, options, start, flow, NULL, NULL,
  NULL, sizeof(chartsweep*)
};

void chartsweep::append_extract(const char* filename, double peak_time,
                                sox_format_t* out) {
  std::cout << "peak energy at " << peak_time << " ... " << std::flush;
  sox_format_t* in = sox_open_read(filename, NULL, NULL, NULL);
  if (!in) {
    std::ostringstream os;
    os << "Error opening file \"" << filename << '"';
    throw std::runtime_error(os.str());
  }
  file_handle in_h(in);

  // adjust start time to have peak in defined position after fade in
  double start_time = peak_time - peak_pos_ - fade_dur_;
  if (start_time < 0.)
    start_time = 0.;

  // make sure it won't extend past end of file
  double duration = ext_dur_;
  if (prev_fade_)
    duration += fade_dur_;
  uint64_t start_pos = start_time * in->signal.rate * in->signal.channels;
  size_t extract_length = in->signal.rate * in->signal.channels * duration;
  if (extract_length >= in->signal.length)
    throw std::runtime_error("file is too short");
  if (start_pos + extract_length >= in->signal.length) {
    start_pos = in->signal.length - extract_length;
    start_time = start_pos / (in->signal.rate * in->signal.channels);
  }

  // try to seek to start position, otherwise trim will skip beginning of file
  if (in->seekable && sox_seek(in, start_pos, SOX_SEEK_SET) == SOX_SUCCESS)
    start_time = 0;

  sox_encodinginfo_t ext_encoding;
  sox_init_encodinginfo(&ext_encoding);
  ext_encoding.encoding = SOX_DEFAULT_ENCODING;
  ext_encoding.bits_per_sample = 0;
  ext_encoding.compression = 0;
  ext_encoding.opposite_endian = sox_false;

  sox_signalinfo_t ext_signal;
  ext_signal.rate = ext_rate_;
  ext_signal.channels = ext_channels_;
  ext_signal.precision = 16;
  ext_signal.length = SOX_IGNORE_LENGTH;
  ext_signal.mult = 0;

  chain_handle chain(&in->encoding, &ext_encoding, &in->signal, &ext_signal);

  // reads input file
  char* effect_args[2];
  effect_args[0] = reinterpret_cast<char*>(in);
  chain.add_effect("input", 1, effect_args);

  // select the extract
  std::string start_time_buf;
  if (start_time) {
    std::ostringstream os;
    os << start_time;
    start_time_buf = os.str();
    effect_args[0] = const_cast<char*>(start_time_buf.c_str());
  }
  else
    effect_args[0] = "0";
  std::string dur_buf;
  std::ostringstream os;
  os << duration;
  dur_buf = os.str();
  effect_args[1] = const_cast<char*>(dur_buf.c_str());
  chain.add_effect("trim", 2, effect_args);

  // mix channels if there are more than two
  if (in->signal.channels > 2) {
    effect_args[0] = "2";
    chain.add_effect("channels", 1, effect_args);
  }

  // resample if sampling rate is different from our target rate
  if (in->signal.rate != 44100) {
    effect_args[0] = "44100";
    chain.add_effect("rate", 1, effect_args);
  }

  // duplicate mono channel
  if (in->signal.channels < 2) {
    effect_args[0] = "2";
    chain.add_effect("channels", 1, effect_args);
  }

  // store result in extract and fade buffers
  effect_args[0] = reinterpret_cast<char*>(this);
  chain.add_effect(effect_handler, 1, effect_args);

  // process everything
  sox_flow_effects(chain.h_, NULL, NULL);
  if (fade_pos_ != fade_len_)
    throw std::runtime_error("error while reading file");

  SOX_SAMPLE_LOCALS;
  size_t clips = 0;
  if (prev_fade_) {
    // crossfade
    double pos = 0.;  
    for (sox_sample_t *fade_in = extract_, *fade_end = extract_ + fade_len_,
                      *fade_out = prev_fade_;
         fade_in != fade_end;
         pos += 2) {
      const double ifac = pos / fade_len_;
      const double ofac = 1. - ifac;
      double s = SOX_SAMPLE_TO_FLOAT_64BIT(*fade_in, clips) * ifac;
      s += SOX_SAMPLE_TO_FLOAT_64BIT(*fade_out, clips) * ofac;
      *fade_in = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      s = SOX_SAMPLE_TO_FLOAT_64BIT(*++fade_in, clips) * ifac;
      s += SOX_SAMPLE_TO_FLOAT_64BIT(*++fade_out, clips) * ofac;
      *fade_in = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      ++fade_in;
      ++fade_out;
    }

    // the end of the current file will be the next fade out
    std::swap(next_fade_, prev_fade_);
  }
  else if (fade_len_) {
    // fade in
    double pos = 0.;  
    for (sox_sample_t *fade_in = extract_, *fade_end = extract_ + fade_len_;
         fade_in != fade_end;
         pos += 2) {
      const double fac = pos / fade_len_;
      double s = SOX_SAMPLE_TO_FLOAT_64BIT(*fade_in, clips) * fac;
      *fade_in = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      s = SOX_SAMPLE_TO_FLOAT_64BIT(*++fade_in, clips) * fac;
      *fade_in = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      ++fade_in;
    }

    // the end of the current file will be the next fade out
    prev_fade_ = next_fade_;

    // setup fade buffer for next file
    next_fade_ = fade_buf_;
  }

  // write to output file the fadein/crossfade and extract
  if (sox_write(out, extract_, store_end_) != store_end_)
    throw std::runtime_error("error writing to result file");
}

void chartsweep::fade_out_last(sox_format_t* out) {
  if (prev_fade_) {
    SOX_SAMPLE_LOCALS;
    size_t clips = 0;
    double pos = 0.;  
    for (sox_sample_t *fade_out = prev_fade_,
                      *fade_end = prev_fade_ + fade_len_;
         fade_out != fade_end;
         pos += 2) {
      const double ifac = pos / fade_len_;
      const double ofac = 1. - (pos / fade_len_);
      double s = SOX_SAMPLE_TO_FLOAT_64BIT(*fade_out, clips) * ofac;
      *fade_out = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      s = SOX_SAMPLE_TO_FLOAT_64BIT(*++fade_out, clips) * ofac;
      *fade_out = SOX_FLOAT_64BIT_TO_SAMPLE(s, clips);
      ++fade_out;
    }

    // write last fade out
    if (sox_write(out, prev_fade_, fade_len_) != fade_len_)
      throw std::runtime_error("error writing to result file");
  }
}

struct add_energy : public std::binary_function<double, sox_sample_t, double> {
  double operator()(double acc, sox_sample_t sample) const {
    SOX_SAMPLE_LOCALS;
    size_t clips;
    double amp = SOX_SAMPLE_TO_FLOAT_64BIT(sample, clips);
    return acc + amp * amp;
  }
};

bool chartsweep::read_chunk(sox_format_t* in) {
  size_t left = chunk_.size();
  sox_sample_t* next_sample = &chunk_[0];
  do {
    size_t samples = sox_read(in, next_sample, left);

    // end of file means the chunk was not complete
    if (samples == 0)
      return false;

    next_sample += samples;
    left -= samples;
  }
  while (left);
  return true;
}

double chartsweep::get_energy(sox_format_t* in) {
  return read_chunk(in)
         ? std::accumulate(chunk_.begin(), chunk_.end(), 0., add_energy())
         : -1.;
}

double chartsweep::find_peak(const char* filename) {
  sox_format_t* in = sox_open_read(filename, NULL, NULL, NULL);
  if (!in) {
    std::ostringstream os;
    os << "Error opening file \"" << filename << '"';
    throw std::runtime_error(os.str());
  }
  file_handle in_h(in);

  const size_t chunk_len = static_cast<size_t>(in->signal.rate * chunk_dur_);
  chunk_.resize(chunk_len * static_cast<size_t>(in->signal.channels));

  // compute search limits in terms of window starting points
  const size_t sig_len = in->signal.length / in->signal.channels;
  const double half_win = chunk_len * chunk_num_ * 0.5;
  size_t min_start = static_cast<size_t>(sig_len * search_start_ - half_win);
  if (min_start < 0)
    min_start = 0;
  size_t max_start = static_cast<size_t>(sig_len * search_stop_ - half_win);

  // skip until eligible position
  size_t cur_start;
  for (cur_start = 0; cur_start < min_start; cur_start += chunk_len)
    if (!read_chunk(in))
      throw std::runtime_error("file is too short");

  // compute first value
  double* next_energy = chunk_energy_;
  double* const energy_end = next_energy + chunk_num_;
  for(;next_energy != energy_end; ++next_energy) {
    *next_energy = get_energy(in);
    if (*next_energy < 0.)
      throw std::runtime_error("file is too short");
  }
  next_energy = chunk_energy_;
  double top_energy = std::accumulate(chunk_energy_, energy_end, 0.);
  size_t top_start = cur_start;

  // evaluate energy while in eligible range
  for (cur_start += chunk_len;
       cur_start <= max_start && (*next_energy = get_energy(in)) >= 0.;
       cur_start += chunk_len) {
    double energy = std::accumulate(chunk_energy_, energy_end, 0.);
    if (energy > top_energy) {
      // update best energy and position
      top_energy = energy;
      top_start = cur_start;
    }

    // oldest value can be discarded
    if (++next_energy == energy_end)
      next_energy = chunk_energy_;
  }

  // peak time is at center of the window
  return static_cast<double>(top_start) / in->signal.rate + peak_offset_;
}
}

int main(int argc, const char* argv[]) {
  double chunk_dur = 0.1, start_at = 0.1, stop_at = 0.9, ext_dur = 10.,
         fade_dur = 1., peak_pos = 0.1;
  size_t chunk_num = 3;
  int pl_arg = 1;
  while (pl_arg < argc - 2 && argv[pl_arg][0] == '-') {
    switch (argv[pl_arg][1]) {
    case 'b':
    case 'e':
    case 'p':
      if (argv[pl_arg][2] == 0) {
        double& limit = argv[pl_arg][1] == 'b'
                        ? start_at
                        : (argv[pl_arg][1] == 'e' ? stop_at : peak_pos);
        if (pl_arg < argc - 3) {
          limit = atof(argv[pl_arg + 1]) * 0.01;
          if (limit < 0. || limit > 1.) {
            std::cerr << "invalid value " << argv[pl_arg + 1] << " for option "
                      << argv[pl_arg] << " (should be between 0 and 100)"
                      << std::endl;
            return -1;
          }
          pl_arg += 2;
          continue;
        }
        else {
          std::cerr << "missing argument to option " << argv[pl_arg]
                    << std::endl;
          return -1;
        }
      }
      break;
    case 'f':
    case 'l':
      if (argv[pl_arg][2] == 0) {
        if (pl_arg < argc - 3) {
          double& dur = argv[pl_arg][1] == 'l' ? ext_dur : fade_dur;
          dur = atof(argv[pl_arg + 1]);
          if (dur < 0. || (dur == 0. && argv[pl_arg][1] == 'l')) {
            std::cerr << "invalid duration " << argv[pl_arg + 1]
                      << " for option " << argv[pl_arg]
                      << " (should be in seconds)"
                      << std::endl;
            return -1;
          }
          pl_arg += 2;
          continue;
        }
        else {
          std::cerr << "missing argument to option " << argv[pl_arg]
                    << std::endl;
          return -1;
        }
      }
      break;
    case 's':
      if (argv[pl_arg][2] == 0) {
        if (pl_arg < argc - 3) {
          chunk_dur = atof(argv[++pl_arg]);
          if (chunk_dur <= 0) {
            std::cerr << "invalid step " << argv[pl_arg]
                      << " (should be positive)" << std::endl;
            return -1;
          }
          ++pl_arg;
          continue;
        }
        else {
          std::cerr << "missing argument to option -s" << std::endl;
          return -1;
        }
      }
      break;
    case 'w':
      if (argv[pl_arg][2] == 0) {
        if (pl_arg < argc - 3) {
          int tmp = atoi(argv[++pl_arg]);
          if (tmp <= 0) {
            std::cerr << "invalid window " << argv[pl_arg]
                      << " (should be positive integer)" << std::endl;
            return -1;
          }
          chunk_num = static_cast<size_t>(tmp);
          ++pl_arg;
          continue;
        }
        else {
          std::cerr << "missing argument to option -w" << std::endl;
          return -1;
        }
      }
      break;
    }
    std::cerr << "unknown option " << argv[pl_arg] << std::endl;
    return -1;
  }
  if (start_at >= stop_at) {
    std::cerr << "inconsistent values for -b and -e options" << std::endl;
    return -1;
  }
  if (fade_dur >= ext_dur) {
    std::cerr << "inconsistent values for -f and -l options" << std::endl;
    return -1;
  }
  if (pl_arg != argc - 2) {
    std::cerr << "Usage "<<argv[0]<<" [options] playlist out_file"<<std::endl
              << "Available options:" << std::endl
              << " -b: % of file where to begin looking for peak (default: 10)"
              << std::endl
              << " -e: % of file where to end looking for peak (default: 90)"
              << std::endl
              << " -f: length of crossfade in seconds (default: 1)"
              << std::endl
              << " -l: length of each extract in seconds (default: 10)"
              << std::endl
              << " -p: peak position in the extract (in % of extract after fade in, default: 10)"
              << std::endl
              << " -s: step (in seconds) for energy function (default: 0.1)"
              << std::endl
              << " -w: window (in number of steps) for energy function (default: 3)"
              << std::endl;
    return 1;
  }

  std::ifstream playlist(argv[pl_arg]);
  if (!playlist.good()) {
    std::cerr << "Could not open playlist \"" << argv[pl_arg] << '"'
              << std::endl;
    return -2;
  }

  if (sox_init() != SOX_SUCCESS) {
    std::cerr << "Error in sox_init " << std::endl;
    return -3;
  }

  sox_signalinfo_t out_info;
  out_info.rate = chartsweep::ext_rate_;
  out_info.channels = chartsweep::ext_channels_;
  out_info.precision = 16;
  out_info.length = SOX_IGNORE_LENGTH;
  out_info.mult = 0;
  sox_format_t* out = sox_open_write(argv[pl_arg + 1], &out_info, NULL, NULL,
                                     NULL, NULL);
  if (!out) {
    std::cerr << "Could not open file \"" << argv[pl_arg + 1] << '"'
              << std::endl;
    return -4;
  }
  int ret = 0;
  int total = 0, ok = 0;
  try {
    file_handle oh(out);
    std::string filename;
    chartsweep sweeper(start_at, stop_at, chunk_dur, chunk_num, ext_dur,
                       fade_dur, peak_pos);
    while (playlist.good()) {
      // skip empty lines
      std::ifstream::int_type c;
      do c = playlist.get();
      while (c == '\r' || c =='\n');
      if (c != std::ifstream::traits_type::eof()) {
        if (c == '#') {
          // skip comment
          do c = playlist.get();
          while (c != std::ifstream::traits_type::eof()
                 && c != '\r' && c != '\n');
        }
        else {
          // read file name
          do {
            filename.push_back(static_cast<char>(c));
            c = playlist.get();
          }
          while (c != std::ifstream::traits_type::eof()
                 && c != '\r' && c != '\n');
        }
      }

      if (!filename.empty()) {
        try {
          ++total;
          std::cout << "processing \"" << filename << "\" ... " << std::flush;
          sweeper.process_file(filename.c_str(), out);
          std::cout << "OK" << std::endl;
          ++ok;
        }
        catch (const std::exception& e) {
          std::cout << " FAILED: " << e.what() << std::endl;
        }
        filename.clear();
      }
    }
    sweeper.fade_out_last(out);
  }
  catch (const std::exception& e) {
    std::cerr << e.what() << std::endl;
    ret = -5;
  }
  
  sox_quit();
  std::cout << std::endl << "Successfully processed " << ok << " files (out of "
            << total << ")" << std::endl << std::endl
            << "Your supercut is complete! Go to " << argv[pl_arg + 1]
            << " and listen" << std::endl;
  return ret;
}

